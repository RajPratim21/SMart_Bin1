package com.example.hello;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity2 extends Activity {
	 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	//	int Total =0;
		TextView tx1;
		Context context = this; 
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);
	//	Total +=5;
	  //  tx1=(TextView)findViewById(R.id.textView2);
		AlertDialog.Builder alertDialog = new AlertDialog.Builder(context);
		alertDialog.setTitle("Thank you for using SmartBin\nYou are a Responsible Citizen");
		alertDialog.setMessage("Your Account Has been\nCredited with 5 points\n");
		alertDialog.setPositiveButton("OK", null);
		AlertDialog Dialog = alertDialog.show();
		 
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
		
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
